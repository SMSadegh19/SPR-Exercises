import json


def load_all_shots(file_name):
    """
    Loads data (list or dict) from a JSON file.
    
    Args:
        file_name (str): The name of the JSON file (with or without .json extension).
    
    Returns:
        list | dict: The data loaded from the JSON file.
    """
    # Ensure filename ends with .json
    if not file_name.endswith(".json"):
        file_name += ".json"
    
    try:
        # Read JSON file
        with open(file_name, "r") as f:
            data = json.load(f)
        print(f"✅ Data successfully loaded from '{file_name}'")
        return data
    except FileNotFoundError:
        print(f"❌ File '{file_name}' not found.")
    except json.JSONDecodeError:
        print(f"❌ File '{file_name}' is not a valid JSON file.")
    except Exception as e:
        print(f"❌ Error loading data: {e}")


def save_dict_or_list_to_json(data, file_name):
    """
    Saves a list or dictionary to a JSON file.
    
    Args:
        data (list | dict): The data to save.
        file_name (str): The name of the JSON file (without .json extension).
    """
    # Check type
    if not isinstance(data, (list, dict)):
        raise TypeError("Only lists and dictionaries can be saved as JSON.")
    
    # Ensure filename ends with .json
    if not file_name.endswith(".json"):
        file_name += ".json"
    
    try:
        # Write JSON file
        with open(file_name, "w") as f:
            json.dump(data, f, indent=4)
        print(f"✅ Data successfully saved to '{file_name}'")
    except Exception as e:
        print(f"❌ Error saving data: {e}")


# --------- Examples to use the function ---------
# Save a dictionary
# my_dict = {"name": "Sharif", "age": 25, "skills": ["Python", "AI", "ML"]}
# save_dict_or_list_to_json(my_dict, "user_data")

# # Save a list
# my_list = ["Python", "Java", "C++"]
# save_dict_or_list_to_json(my_list, "languages")
# --------- End of examples ---------

# THIS IS A LIST OF ALL SHOTS:
all_shots = load_all_shots("non_penalty_shots.json")

# TODO: You should complete the follwoing code:
# MSBGA: MAKE SHAHID BEHESHTI GREAT AGAIN

sample_shot_index = 291

print("TOTAL NUMBER OF SHOTS:")
print(len(all_shots))
print("-----------")
print("DETAILS OF A SAMPLE SHOT:")
print(all_shots[sample_shot_index])
print("-----------")
print("LOCATION OF OPONNETS WHILE SHOOTING:")
print(all_shots[sample_shot_index]["shot_freeze_frame"])
print("-----------")
print("IS HE UNDER PRESSURE WHILE SHOOTING?")
print(all_shots[sample_shot_index]["under_pressure"])

# TODO: YOU CODE HERE
for i in range(len(all_shots)):
    pass
    # TODO: YOUR CODE
