import json
import random

def load_from_json(file_name):
    """
    Loads data (list or dict) from a JSON file.
    
    Args:
        file_name (str): The name of the JSON file (with or without .json extension).
    
    Returns:
        list | dict: The data loaded from the JSON file.
    """
    # Ensure filename ends with .json
    if not file_name.endswith(".json"):
        file_name += ".json"
    
    try:
        # Read JSON file
        with open(file_name, "r") as f:
            data = json.load(f)
        print(f"✅ Data successfully loaded from '{file_name}'")
        return data
    except FileNotFoundError:
        print(f"❌ File '{file_name}' not found.")
    except json.JSONDecodeError:
        print(f"❌ File '{file_name}' is not a valid JSON file.")
    except Exception as e:
        print(f"❌ Error loading data: {e}")


# # --------- Examples to use the function ---------
# # Load previously saved dictionary
# user_data = load_from_json("user_data")
# print(user_data)
# print(type(user_data))

# # Load previously saved list
# languages = load_from_json("languages")
# print(languages)
# print(type(languages))
# # --------- End of examples ---------


def calculate_xg(shot_info):
    # In this function, you should return an int number between 1 to 99
    # TODO: You should change this function code:
    # YOU CODE HERE
    # MSBGA: MAKE SHAHID BEHESHTI GREAT AGAIN
    return random.randint(1, 99)
